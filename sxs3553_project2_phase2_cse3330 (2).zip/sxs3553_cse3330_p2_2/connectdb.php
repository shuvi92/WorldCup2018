
<?php

//connecting php to mysqldatabase
/* 
Subhechha Shrestha
1001393553
*/

$user = 'root';
$pass = '';

$db = 'sxs3553_2_2_';

$conn = mysqli_connect('localhost', $user, $pass, $db) or die("Unable to connect");

if($conn){
	echo "Conncetion established! <br>";
}else{
	die("Connection failed.Reason:".mysqli_connect_error());
}

?>﻿

 

<html>
	<head>
		<title> World Cup Database </title>
		</head>
		<body>
		
		<form action = "connectdb.php" method = "post">
Enter a country name to display the Game ID, in which this team played, followed by the player name, who was in the
starting lineup for this game, and the player no of the player, sorted by the Game ID and Player no: <br><br>

Country Name:<input type="test" name = "cname"><br><br>
<button type = "submit"> Enter </button>

</form>

		
		<?php
		
	        $name = $_POST["cname"];	//this stores the user input in variable name
			
						
			//select statement to select data from mysql
			$sql = "SELECT game.gameid,player.pname,player.pno  
FROM player,startinglineup,game 
WHERE (startinglineup.pno,startinglineup.teamid) = (player.pno,player.teamid) AND startinglineup.gameid= game.gameid AND player.team_name = '$name' 
ORDER BY game.gameid,player.pno";

			//this makes sure the input is not empty

			if(empty($name)){
echo "<center><b>WRITE SOMETHING IN THE SEARCH FIELD</center></b><br/>";
}
			$result = mysqli_query($conn,$sql);
			
			//check if the rows are greater than 0 to verify result
			if(mysqli_num_rows($result)>0){
			
			//this displays the result
			while($row = mysqli_fetch_assoc($result)){	
			echo  "gameid:".$row["gameid"]. "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp" ."pname:".$row["pname"]. "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp"."pnumber:".$row["pno"];
			echo "<br>";
			}
			} else {
				echo "0 results";
			}
			
			//close the connection
			mysqli_close($conn);
			
			?>
			
			</body>
			</html>