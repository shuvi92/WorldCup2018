
<?php

//Subhechha Shrestha
//1001393553

$user = 'root';
$pass = '';

$db = 'sxs3553_2_2_';

$conn = mysqli_connect('localhost', $user, $pass, $db) or die("Unable to connect");

if($conn){
	echo "Connection established! <br>";
}else{
	die("Connection failed.Reason:".mysqli_connect_error());
}

?>﻿

<html>
	<head>
		<title> World Cup Database </title>
		</head>
		<body>
		
		<form action = "connectdb2.php" method = "post">
Enter a country name (Russia, Brazil etc) and card color (Yellow, Red) to retrieve and
display the results of all games and player names that played in that game and
received a card of that color. <br><br>
Country name: <input type="text" name = "cname"><br><br>
Card Color: <input type="text" name = "color"><br><br>
<button type = "submit"> Enter </button>

</form>

		
		<?php
		
	        $name = $_POST["cname"];	
			$card = $_POST["color"];
			$sql = "SELECT game.gameid,player.pname,cards.color
FROM cards,game,player
WHERE (cards.pno,cards.teamid) = (player.pno,player.teamid) AND cards.gameid= game.gameid AND player.team_name = '$name' AND cards.color = '$card'";
			
if(empty($name)|| empty($card))
{
echo "<center><b>WRITE SOMETHING IN THE SEARCH FIELD</center></b><br/>";
}
			$result = mysqli_query($conn,$sql);
			
			if(mysqli_num_rows($result)>0){
			
			while($row = mysqli_fetch_assoc($result)){	
			echo  "Game Id:".$row["gameid"]. "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp" ."Player Name:".$row["pname"]. "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp" ."Card's color:".$row["color"];
			echo "<br>";
			}
			} else {
				echo "0 results";
			}
			
			
			mysqli_close($conn);
			
			?>
			
			</body>
			</html>